//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<safecert_face_recognition/SafecertFaceRecognitionPlugin.h>)
#import <safecert_face_recognition/SafecertFaceRecognitionPlugin.h>
#else
@import safecert_face_recognition;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [SafecertFaceRecognitionPlugin registerWithRegistrar:[registry registrarForPlugin:@"SafecertFaceRecognitionPlugin"]];
}

@end
