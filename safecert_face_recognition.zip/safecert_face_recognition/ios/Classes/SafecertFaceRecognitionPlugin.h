#import <Flutter/Flutter.h>

@interface SafecertFaceRecognitionPlugin : NSObject<FlutterPlugin>
@end
